# osrs
student registration
